app.controller('pavilionListCtrl', function($scope, pavilionModel, $rootScope) {
	console.log('pavilionListCtrl');
});