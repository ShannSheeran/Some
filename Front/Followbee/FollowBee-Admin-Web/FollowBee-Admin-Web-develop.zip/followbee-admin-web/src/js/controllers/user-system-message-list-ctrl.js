/**
* @Author: Kongho
* @Date:   2017-01-20 11:54:35
* @Email:  kongho@3ncto.com
* @Filename: user-system-message-list-ctrl.js
* @Last modified by:   Kongho
* @Last modified time: 2017-01-22 22:08:20
* @Copyright: 3NCTO Co., Ltd.
*/



app.controller('userSystemMessageListCtrl', function($scope, userModel, $rootScope) {
	console.log('userSystemMessageListCtrl');
});
