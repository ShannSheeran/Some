/**
* @Author: Kongho
* @Date:   2017-01-20 11:54:35
* @Email:  kongho@3ncto.com
* @Filename: user-model.js
* @Last modified by:   Kongho
* @Last modified time: 2017-01-21 18:52:40
* @Copyright: 3NCTO Co., Ltd.
*/



app.service('userModel', function(baseModel, apiConfig, $rootScope){
	console.log('userModel');
});
