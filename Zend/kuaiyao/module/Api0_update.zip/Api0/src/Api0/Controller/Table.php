<?php
namespace Api0\Controller;

use Admin\Controller\TableController;

class Table extends TableController
{
}